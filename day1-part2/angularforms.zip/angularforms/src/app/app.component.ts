import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Forms In Angular</h1>
    <hr>
    <h1>Template Form</h1>
    <app-template-form></app-template-form>
    <hr>
    <h1>Reactive Form</h1>
    <app-reactive-form></app-reactive-form>
  `,
  styles: []
})
export class AppComponent {
  title = 'angularforms';
}
