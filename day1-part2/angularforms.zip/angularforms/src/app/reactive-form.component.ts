import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  template: `
   <form (submit)="formSubmitHandler()" [formGroup]="userForm" action="#">
     <label for="username">User Name</label>
     <input  formControlName="username" required id="username">
     <span *ngIf="userForm.get('username').invalid && userForm.get('username').touched" style="color : crimson"> Please enter your name </span>
     <br>
     <label for="usermail">User eMail</label>
     <input  formControlName="usermail" pattern=".+@.+" required id="usermail">
     <br>
     <label for="userage">User Age</label>
     <input formControlName="userage" required id="userage" >
     <br>
     <button>Register</button>
   </form>
   <p>
     User Name : {{ userForm.get('username').value }}<br>
     User Mail : {{ userForm.get('usermail').value }}<br>
     User Age : {{ userForm.get('userage').value }}
   </p>
  <ul>
    <li *ngIf="userForm.get('username').touched"> UserName : Touched </li>
    <li *ngIf="userForm.get('username').untouched"> UserName : UnTouched </li>
    <li *ngIf="userForm.get('username').pristine"> UserName : Pristine </li>
    <li *ngIf="userForm.get('username').dirty"> UserName : Dirty </li>
    <li *ngIf="userForm.get('username').valid"> UserName : Valid </li>
    <li *ngIf="userForm.get('username').invalid"> UserName : InValid </li>
  </ul>
  <ul>
    <li *ngIf="userForm.get('usermail').touched"> User Mail : Touched </li>
    <li *ngIf="userForm.get('usermail').untouched"> User Mail : UnTouched </li>
    <li *ngIf="userForm.get('usermail').pristine"> User Mail : Pristine </li>
    <li *ngIf="userForm.get('usermail').dirty"> User Mail : Dirty </li>
    <li *ngIf="userForm.get('usermail').valid"> User Mail : Valid </li>
    <li *ngIf="userForm.get('usermail').invalid"> User Mail : InValid </li>
  </ul>
  <ul>
    <li *ngIf="userForm.get('userage').touched"> User Age : Touched </li>
    <li *ngIf="userForm.get('userage').untouched"> User Age : UnTouched </li>
    <li *ngIf="userForm.get('userage').pristine"> User Age : Pristine </li>
    <li *ngIf="userForm.get('userage').dirty"> User Age : Dirty </li>
    <li *ngIf="userForm.get('userage').valid"> User Age : Valid </li>
    <li *ngIf="userForm.get('userage').invalid"> User Age : InValid </li>
  </ul>
  `,
  styles: [`
    label, button{ width : 100px; display : inline-block; margin : 5px }
    button{ margin-left : 110px }
    input.ng-invalid.ng-touched{ border : 3px solid crimson }
    input.ng-valid.ng-touched{ border : 3px solid darkseagreen }
  `]
})
export class ReactiveFormComponent{
  userForm:FormGroup;
  constructor() { 
    this.userForm = new FormGroup({
      username : new FormControl(),
      usermail : new FormControl(),
      userage : new FormControl()
    })
  }
  
  formSubmitHandler(){
    if(!this.userForm.get('userage').value){
      alert("please enter your age");
    }else{
      if( this.userForm.get('userage').value < 18){
        alert("you are too young to joing us");
      }else if(this.userForm.get('userage').value > 90){
        alert("you are too old to joing us");
      }else{
        alert("are you ready to joing us");
      }
    }
  }

}
