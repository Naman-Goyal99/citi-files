import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-form',
  template: `
   <form #myForm="ngForm" action="#" method="get" (submit)="formSubmitHandler(myForm, $event)">
     <label for="username">User Name</label>
     <input #unameIp="ngModel" [(ngModel)]="username" required id="username" type="text" name="userName" >
     <span *ngIf="unameIp.touched && unameIp.invalid" style="color : crimson"> Please enter your name </span>
     <br>
     <label for="usermail">User eMail</label>
     <input #umailIp="ngModel" [(ngModel)]="usermail" pattern=".+@.+" required id="usermail" type="text" name="userMail" >
     <br>
     <label for="userage">User Age</label>
     <input #uageIp="ngModel" [(ngModel)]="userage" required id="userage" type="text" name="userAge" >
     <br>
     <button>Register</button>
   </form>
   <p>
     User Name : {{ username }}<br>
     User Mail : {{ usermail }}<br>
     User Age : {{ userage }}
   </p>
  <ul>
    <li *ngIf="unameIp.touched"> UserName : Touched </li>
    <li *ngIf="unameIp.untouched"> UserName : UnTouched </li>
    <li *ngIf="unameIp.pristine"> UserName : Pristine </li>
    <li *ngIf="unameIp.dirty"> UserName : Dirty </li>
    <li *ngIf="unameIp.valid"> UserName : Valid </li>
    <li *ngIf="unameIp.invalid"> UserName : InValid </li>
  </ul>
  <ul>
    <li *ngIf="umailIp.touched"> User Mail : Touched </li>
    <li *ngIf="umailIp.untouched"> User Mail : UnTouched </li>
    <li *ngIf="umailIp.pristine"> User Mail : Pristine </li>
    <li *ngIf="umailIp.dirty"> User Mail : Dirty </li>
    <li *ngIf="umailIp.valid"> User Mail : Valid </li>
    <li *ngIf="umailIp.invalid"> User Mail : InValid </li>
  </ul>
  <ul>
    <li *ngIf="uageIp.touched"> User Age : Touched </li>
    <li *ngIf="uageIp.untouched"> User Age : UnTouched </li>
    <li *ngIf="uageIp.pristine"> User Age : Pristine </li>
    <li *ngIf="uageIp.dirty"> User Age : Dirty </li>
    <li *ngIf="uageIp.valid"> User Age : Valid </li>
    <li *ngIf="uageIp.invalid"> User Age : InValid </li>
  </ul>
  `,
  styles: [`
    label, button{ width : 100px; display : inline-block; margin : 5px }
    button{ margin-left : 110px }
    input.ng-invalid.ng-touched{ border : 3px solid crimson }
    input.ng-valid.ng-touched{ border : 3px solid darkseagreen }
  `]
})
export class TemplateFormComponent{
  username:any;
  usermail:any;
  userage:any;
  constructor() { }

  ngOnInit(): void {

  }

  formSubmitHandler(userForm, evt){
    evt.preventDefault();
    //console.log(userForm);
    //console.log(evt);
    if(!userForm.value.userAge){
      alert("please enter your age");
    }else{
      if( userForm.value.userAge < 18){
        alert("you are too young to joing us");
      }else if(userForm.value.userAge > 90){
        alert("you are too old to joing us");
      }else{
        alert("are you ready to joing us");
        evt.target.submit();
      }
    }
  }

}
