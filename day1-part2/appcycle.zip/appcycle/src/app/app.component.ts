import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
      <h1>Application Cycle Hooks</h1>
      <button (click)="show = !show">Show / Hide</button>
      <button (click)="power = power+1">Increase Power</button>
      <input #ti (input)="power = ti.value" type="number">
      <input type="number" [(ngModel)]="power">
      <hr>
      <app-child *ngIf="show" [pow]="power"></app-child>
  `,
  styles: []
})
export class AppComponent {
  power:any = 0;
  show = true;
  title = 'appcycle';
  constructor(){
    console.log("AppComponent constructor called");
  }
ngOnInit(){
    console.log("AppComponent ngOnInit called");
}
ngOnChanges(){
    console.log("AppComponent ngOnChanges called ")
}
ngOnDestroy(){
    console.log("AppComponent ngOnDestroy called ")
}
ngAfterViewInit(){
    console.log("AppComponent ngAfterViewInit called ")
}
ngAfterContentInit(){
    console.log("AppComponent ngAfterContentInit called ")
}
ngAfterViewChecked(){
    console.log("AppComponent ngAfterViewChecked called ")
}
ngDoCheck(){
    console.log("AppComponent ngDoCheck called ")
}
}
