import { AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit } from "@angular/core";
@Component({
    selector : 'app-child',
    template : `
        <h2>Child Component</h2>
        <h3>Power is : {{ pow }}</h3>
    `
})
export class ChildComponent implements  OnInit, 
                                        OnChanges, 
                                        OnDestroy, 
                                        AfterViewInit, 
                                        AfterContentInit, 
                                        AfterViewChecked, 
                                        DoCheck{
    constructor(){
        console.log("ChildComponent constructor called");
    }
    @Input() pow:any;
    ngOnInit(){
        console.log("ChildComponent ngOnInit called");
    }
    ngOnChanges(){
        console.log("ChildComponent ngOnChanges called ")
    }
    ngOnDestroy(){
        console.log("ChildComponent ngOnDestroy called ")
    }
    ngAfterViewInit(){
        console.log("ChildComponent ngAfterViewInit called ")
    }
    ngAfterContentInit(){
        console.log("ChildComponent ngAfterContentInit called ")
    }
    ngAfterViewChecked(){
        console.log("ChildComponent ngAfterViewChecked called ")
    }
    ngDoCheck(){
        console.log("ChildComponent ngDoCheck called ")
    }
}