import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Communication</h1>
    <h1>First Child Component</h1>
    <app-child>
      <ul>
        <li>List Item 1</li>
        <li>List Item 2</li>
        <li>List Item 3</li>
      </ul>
      <ul class="secondlist">
        <li>List Item 1 with CLASS</li>
        <li>List Item 2 with CLASS</li>
        <li>List Item 3 with CLASS</li>
      </ul>
      <ul id="thirdlist">
        <li>List Item 1 with ID</li>
        <li>List Item 2 with ID</li>
        <li>List Item 3 with ID</li>
      </ul>
      <p>
        First Paragraph
        <br>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda pariatur neque odit nostrum? Corporis rem, atque! Laboriosam iusto ab praesentium ipsam, esse similique magnam commodi cupiditate at harum mollitia blanditiis.
      </p>
      <p title="2ndpara">
        Second Paragraph
        <br>
        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda pariatur neque odit nostrum? Corporis rem, atque! Laboriosam iusto ab praesentium ipsam, esse similique magnam commodi cupiditate at harum mollitia blanditiis.
      </p>
      <div class="box">First</div>
      <div>Second</div>
      <div>Third</div>
      <div>Fourth</div>
      <div class="box">Fifth</div>
    </app-child>
    <hr>
    <h1>Second Child Component</h1>
    <h4>Message from child component  : {{ childmessage }} </h4>
    <app-second (sholay)="sholayHandler($event)" bahubali="{{ title }}" [sp]="message"></app-second>
  `,
  styles: []
})
export class AppComponent {
  title = 'communication';
  childmessage = 'empty';
  message = 'Welcome to your life';
  sholayHandler(msg){
    // ("Sholay event happened "+msg);
    this.childmessage = msg;
  }
}
