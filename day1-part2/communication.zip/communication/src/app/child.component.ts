import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <p>
      child works!
      <br>
    </p>
    <h2>List with class</h2>
    <ng-content select=".secondlist"></ng-content>
    <hr>
    <h2>List with id</h2>
    <ng-content select="#thirdlist"></ng-content>
    <hr>
    <h2>List</h2>
    <ng-content select="ul"></ng-content>
    <hr>
    <h2>Second Paragraphs</h2>
    <ng-content select="[title='2ndpara']"></ng-content>
    <hr>
    <h2>First Paragraphs</h2>
    <ng-content select="p"></ng-content>
    <h2>First and Fifth div</h2>
    <ng-content select=".box"></ng-content>
  `,
  styles: [
  ]
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
