import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';


@Component({
  selector: 'app-second',
  template: `
    <p>
      second works!
    </p>
    <h4>Sarpatta {{ sarpatta }}</h4>
    <h4>Bahubali {{ bahubali }}</h4>
    <hr>
    <input #ti type="text">
    <button (click)="sendMessageToParent(ti.value)">Send Message</button>
  `,
  styles: [
  ]
})
export class SecondComponent implements OnInit {
  @Input('sp') sarpatta = "New Tamil Movie";
  @Input() bahubali = "Telugu Movie";
  @Output() sholay:EventEmitter<any> = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  sendMessageToParent(message){
    this.sholay.emit(message)
  }
}
