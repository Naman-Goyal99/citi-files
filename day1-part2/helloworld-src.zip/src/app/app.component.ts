import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1> Hello There </h1> 
  <p class="{{ styleName }}">{{ title }}</p>
  <input type="{{ tagtype }}">
  <h2>{{ title }}</h2>
  <ol>
    <li>
      <h2 innerHTML="{{ title }}"></h2>
    </li>
    <li>
      <h2 innerText="{{ title }}"></h2>
    </li>
    <li>
      <h2 textContent="{{ title }}"></h2>
    </li>
    <li>
      <h2 [innerHTML]="title"></h2>
    </li>
  </ol>
  <hr>
  <input type="text" [value]="title">
  <button (click)="clickHandler()">Click Me</button>
  <hr>
  <input (change)="changeAgreeHandler()" type="checkbox" [checked]="agree">
  <p [hidden]="agree">
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis enim possimus odit officiis quidem, expedita modi necessitatibus sint rerum, quam, asperiores nihil, eveniet repellat! Dolorem magnam distinctio expedita eos facilis.
  </p>
  <p *ngIf="!agree">
    Shown via *ngIf directive
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quis enim possimus odit officiis quidem, expedita modi necessitatibus sint rerum, quam, asperiores nihil, eveniet repellat! Dolorem magnam distinctio expedita eos facilis.
  </p>
  <ol>
    <li *ngFor="let hero of avengers">{{ hero }}</li>
  </ol>
  <app-first></app-first>
  `,
  styles : [`
    .redBox{ width : 200px; height : 100px; color : white;  background-color: green; font-family : 'arial'}
  `]
})
export class AppComponent {
  title = 'hello citi bank';
  tagtype = 'number';
  styleName = 'redBox';
  agree = false;
  avengers = ['Ironman','Hulk','Thor','Captain America', 'Groot', 'Antman','Spiderman'];
  clickHandler(){
    alert("you clicked the button")
  }
  changeAgreeHandler(){
    this.agree = !this.agree;
  }
}
