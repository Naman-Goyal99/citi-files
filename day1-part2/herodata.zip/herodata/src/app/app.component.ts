import { Component } from '@angular/core';
import { HeroService } from './herodata.service';
     
@Component({
  selector: 'app-root',
  template: `
  <div class="container">
  <h1 class="display-1 text-center">Heroes List</h1>
  <app-header [herodata]="herolist"></app-header>
  <hr>
  <app-grid [herodata]="herolist"></app-grid>
  </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'herolist';
  herolist:any;
  /* heroservice:HeroService = new HeroService();
  constructor(){
      this.herolist = this.heroservice.getData();
  } */

  constructor(private heroservice:HeroService){
    // this.herolist = this.heroservice.getData();
    this.heroservice.getData().subscribe((res)=>{
       // console.log(res);
       this.herolist = res;
    })
  }

}