import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { GridComp } from './components/grid.component';
import { HeaderComp } from './components/header.component';
import { HeroService } from './herodata.service';

@NgModule({
  declarations: [ AppComponent, HeaderComp, GridComp ],
  imports: [ BrowserModule, HttpClientModule ],
  providers: [ HeroService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
