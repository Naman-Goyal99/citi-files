import { Component, Input } from "@angular/core";

@Component({
    selector : 'app-grid',
    template : `
    <table class="table table-striped table-responsive table-sm">
    <thead class="table-dark">
      <tr>
        <th>Sl #</th>
        <th>Title</th>
        <th>Poster</th>
        <th>Full Name</th>
        <th>City</th>
        <th>Ticket Price</th>
        <th>Release Date</th>
        <th>Movies</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of herodata">
        <td>{{ hero.sl }}</td>
        <td>{{ hero.title | uppercase }}</td>
        <td>
          <img class="img-thumbnail" width="50" src="{{ hero.poster }}" alt="{{ hero.title }}">
        </td>
        <td>{{ hero.firstname+' '+hero.lastname }}</td>
        <td>{{ hero.city }}</td>
        <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '4.2-3' }}</td>
        <td>{{ hero.releasedate | date : 'dd / MMM / yyyy' }}</td>
        <td>
            <img class="img-thumbnail" *ngFor="let movie of hero.movieslist" width="50" src="{{ movie.poster }}" alt="{{ movie.title }}">
        </td>
      </tr>
    </tbody>
  </table>
    `
})
export class GridComp{
    @Input() herodata:any;
}