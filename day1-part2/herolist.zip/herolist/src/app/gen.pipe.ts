import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'gen'
})
export class GenPipe implements PipeTransform {
    transform(arg1:string, arg2:string):string{
       // return arg1.toUpperCase()
       // return arg1[0]
       // return "Mr "+arg1+" "+arg2;
       if(arg2 === 'female'){
           return "Miss "+arg1;
        }else{
           return "Mr "+arg1;
       }
    }
}