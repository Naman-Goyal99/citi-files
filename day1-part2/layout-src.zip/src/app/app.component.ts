import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template : `
  <h1>2nd Angular Project</h1>
  <app-header></app-header>
  <app-main></app-main>
  <app-footer></app-footer>
  `
})
export class AppComponent {
  title = 'layout';
}
