import { Component } from '@angular/core';

@Component({
  selector: 'app-article',
  template : `
  <div style="border : 2px solid black; margin : 10px; padding : 10px">
      <h1>Article Component</h1>
      <p>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam excepturi, praesentium ratione delectus earum pariatur at quod neque deserunt, nostrum voluptatum modi eaque ducimus quos obcaecati voluptate nisi quam eos!
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam excepturi, praesentium ratione delectus earum pariatur at quod neque deserunt, nostrum voluptatum modi eaque ducimus quos obcaecati voluptate nisi quam eos!
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam excepturi, praesentium ratione delectus earum pariatur at quod neque deserunt, nostrum voluptatum modi eaque ducimus quos obcaecati voluptate nisi quam eos!
      </p>

      <p>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nihil, minima molestiae illum aspernatur facere. Quos error obcaecati nam architecto omnis velit, quidem, accusamus veniam odit, ab culpa voluptatibus animi autem.
      </p>
  </div>
  `
})
export class ArticleComponent {
  title = 'layout';
}
