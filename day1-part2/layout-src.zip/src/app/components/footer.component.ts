import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  template : `
  <div style="border : 2px solid black; margin : 10px; padding : 10px">
      <h3>Footer Component</h3>
  </div>
  `
})
export class FooterComponent {
  title = 'layout';
}
