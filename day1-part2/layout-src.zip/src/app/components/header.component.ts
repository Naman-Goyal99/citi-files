import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  template : `
  <div style="border : 2px solid black; margin : 10px; padding : 10px">
    <h1>Header Component</h1>
  </div>
  `
})
export class HeaderComponent {
  title = 'layout';
}
