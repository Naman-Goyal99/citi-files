import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  template : `
  <div style="border : 2px solid black; margin : 10px; padding : 10px">
    <h1>Main Component</h1>
    <app-article></app-article>
    <app-article></app-article>
  </div>
  `
})
export class MainComponent {
  title = 'layout';
}
