import { Component } from '@angular/core';
/* dont use this code
      <a href="">Home</a> | 
     <a href="batman">Batman</a> | 
     <a href="superman">Superman</a> | 
     <a href="flash">Flash</a> | 
     <a href="wonder">Wonder Women</a> | 
     <a href="aquaman">Aquaman</a> | 
     <a href="cyborg">Cyborg</a> | 
     <a href="nulk">Hulk</a>  
*/
/*
  <a routerLink="">Home</a> | 
  <a routerLink="batman">Batman</a> | 
  <a routerLink="superman">Superman</a> | 
  <a routerLink="flash">Flash</a> | 
  <a routerLink="wonder">Wonder Women</a> | 
  <a routerLink="aquaman">Aquaman</a> | 
  <a routerLink="cyborg">Cyborg</a> | 
  <a routerLink="nulk">Hulk</a> 
*/
/*
  <a [routerLink]="['']">Home</a> | 
  <a [routerLink]="['batman']">Batman</a> | 
  <a [routerLink]="['superman']">Superman</a> | 
  <a [routerLink]="['flash']">Flash</a> | 
  <a [routerLink]="['wonder']">Wonder Women</a> | 
  <a [routerLink]="['aquaman']">Aquaman</a> | 
  <a [routerLink]="['cyborg']">Cyborg</a> | 
  <a [routerLink]="['hulk']">Hulk</a>     
*/
@Component({
  selector: 'app-root',
  template: `
  <a routerLinkActive="selectedLink" [routerLinkActiveOptions]="{ exact : true }"  [routerLink]="['/']">Home</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/batman']">Batman</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/superman']">Superman</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/flash']">Flash</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/wonder']">Wonder Women</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/aquaman']">Aquaman</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/cyborg']">Cyborg</a> | 
  <a routerLinkActive="selectedLink" [routerLink]="['/hulk']">Hulk</a> 
    <hr>
    <router-outlet></router-outlet>
  `,
  styles: [`
  a{
    padding : 5px;
    font-family : arial;
    text-decoration : none;
    color : black;
  }
  .selectedLink{
    background-color : crimson;
    color : white;
  }
  `]
})
export class AppComponent {
  title = 'routesfun';
}
