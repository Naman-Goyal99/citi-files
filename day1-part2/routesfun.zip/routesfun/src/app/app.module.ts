import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { BatmanComponent } from './batman.component';
import { FlashComponent } from './flash.component';
import { AquamanComponent } from './aquaman.component';
import { WonderwomenComponent } from './wonderwomen.component';
import { SupermanComponent } from './superman.component';
import { CyborgComponent } from './cyborg.component';
import { RouterModule } from '@angular/router';
import { NotfoundComponent } from './notfound.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BatmanComponent,
    FlashComponent,
    AquamanComponent,
    WonderwomenComponent,
    SupermanComponent,
    CyborgComponent
  ],
  imports: [
    BrowserModule, FormsModule, RouterModule.forRoot([
      { path : '', component : HomeComponent },
      { path : 'batman', component : BatmanComponent},
      { path : 'flash', component : FlashComponent},
      { path : 'aquaman', component : AquamanComponent},
      { path : 'aquaman/:units', component : AquamanComponent},
      { path : 'wonder', component : WonderwomenComponent},
      { path : 'superman', component : SupermanComponent},
      { path : 'cyborg', component : CyborgComponent},
      { path : '**', component : NotfoundComponent},
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
