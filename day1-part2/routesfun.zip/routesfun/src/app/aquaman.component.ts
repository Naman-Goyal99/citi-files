import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-aquaman',
  template: `
    <h1>
      aquaman works!
      <h2>Product In Stock : {{ productInStock }}</h2>
    </h1>
  `,
  styles: [
  ]
})
export class AquamanComponent implements OnInit {
  productInStock = 0;
  constructor( private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.productInStock = this.ar.snapshot.params['units'];
  }

}
