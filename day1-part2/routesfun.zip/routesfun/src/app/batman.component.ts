import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-batman',
  template: `
    <h1>
      batman works!
    </h1>
    <input type="range" [(ngModel)]="aquaQuantity">Selected quantity is : {{ aquaQuantity }}
    <hr>
    <a [routerLink]="['/']">Home</a> | 
    <a [routerLink]="['/batman']">Batman</a> | 
    <a [routerLink]="['/superman']">Superman</a> | 
    <a [routerLink]="['/flash']">Flash</a> | 
    <a [routerLink]="['/wonder']">Wonder Women</a> | 
    <a [routerLink]="['/aquaman']">Aquaman</a> | 
    <a [routerLink]="['/aquaman',aquaQuantity]">Aquaman</a> | 
    <a [routerLink]="['/cyborg']">Cyborg</a> | 
    <a [routerLink]="['/hulk']">Hulk</a> 

  `,
  styles: [
  ]
})
export class BatmanComponent implements OnInit {
  aquaQuantity;
  constructor() { }

  ngOnInit(): void {
  }

}
