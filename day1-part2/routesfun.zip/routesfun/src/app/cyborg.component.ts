import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cyborg',
  template: `
    <h1>
      cyborg works!
    </h1>
  `,
  styles: [
  ]
})
export class CyborgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
