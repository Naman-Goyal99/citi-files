import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superman',
  template: `
    <h1>
      superman works!
    </h1>
  `,
  styles: [
  ]
})
export class SupermanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
