import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wonderwomen',
  template: `
    <h1>
      wonderwomen works!
    </h1>
  `,
  styles: [
  ]
})
export class WonderwomenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
